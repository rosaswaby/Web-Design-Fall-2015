$(document).ready(function(){

  $(".main-image").click(function(){
    $("body").css("background", "#FAFAD2");
  })


  $('img').hide();
  $('img').fadeIn("slow");

  $('#paragraph1').hide();
  $( "#paragraph1" ).slideDown( 1000 );

  $('#paragraph2').hide();
  $( "#paragraph2" ).slideDown( 1000 );

  $('#paragraph3').hide();
  $( "#paragraph3" ).slideDown( 1000 );

  $('#paragraph4').hide();
  $( "#paragraph4" ).slideDown( 1000 );


  $("#paragraph1, #paragraph2, #paragraph3, #paragraph4").mouseover(function(){
    $("#paragraph1, #paragraph2, #paragraph3, #paragraph4").css("font-size", "30px");
});


  $("#paragraph1, #paragraph2, #paragraph3, #paragraph4").mouseout(function(){
    $("#paragraph1, #paragraph2, #paragraph3, #paragraph4").css("font-size", "20px");
});


$( ".footer-text" ).click(function() {
    alert( "You are going to another site! Click okay to continue." );
});





})
